# tests/test_main.py
import os
import sys
import re
import subprocess
from pathlib import Path

PYTHON = sys.executable
ROOT = Path(__file__).resolve().parents[1]
MAIN_PATH = ROOT / "src" / "main.py"   # varsayılan hedef
MAIN = os.getenv("APP_MAIN", str(MAIN_PATH))

# Dosya gerçekten var mı? (APP_MAIN ile override edilmişse onu kontrol eder)
assert Path(MAIN).exists(), f"Çalıştırılacak dosya bulunamadı: {MAIN}"

def run_prog(lines):
    """Komutları satır satır verip (stdin), rc/out/err döndürür."""
    data = ("\n".join(lines) + "\n").encode("utf-8")
    cp = subprocess.run([PYTHON, MAIN], input=data, capture_output=True)
    out = cp.stdout.decode("utf-8", errors="ignore")
    err = cp.stderr.decode("utf-8", errors="ignore")
    return cp.returncode, out, err


# --- Smoke: sadece kapat ---
def test__smoke_only_kapat():
    rc, out, err = run_prog(["kapat"])
    assert "Program kapatıldı." in out, f"stdout boş.\nstderr:\n{err}"
    assert rc == 0, f"rc={rc}\nstderr:\n{err}"
    assert err == ""


# TODO[1]: ekle
def test_todo1_ekle_prints_eklendi():
    rc, out, err = run_prog([
        "ekle",
        "Ali", "Yilmaz", "01.01.1990", "Erkek", "50000",
        "kapat"
    ])
    assert rc == 0, f"rc={rc}\nstderr:\n{err}"
    assert "Eklendi" in out
    assert "Program kapatıldı." in out
    assert err == ""


# TODO[2]: sil
def test_todo2_sil_existing_then_deleted():
    rc, out, err = run_prog([
        "ekle",
        "Ali", "Yilmaz", "01.01.1990", "Erkek", "50000",
        "sil",
        "C00001",
        "kapat"
    ])
    assert rc == 0, f"rc={rc}\nstderr:\n{err}"
    assert "Eklendi" in out
    assert "Silindi" in out
    assert "Program kapatıldı." in out

def test_todo2_sil_non_existing_prints_bulunamadi():
    rc, out, err = run_prog([
        "sil",
        "C00005",
        "kapat"
    ])
    assert rc == 0, f"rc={rc}\nstderr:\n{err}"
    assert "Bulunamadi" in out
    assert "Program kapatıldı." in out


# TODO[3]: bul
def test_todo3_bul_non_existing_prints_yok():
    rc, out, err = run_prog([
        "bul",
        "C00001",
        "kapat"
    ])
    assert rc == 0, f"rc={rc}\nstderr:\n{err}"
    assert "YOK" in out
    assert "Program kapatıldı." in out

def test_todo3_bul_existing_prints_formatted_single_line():
    rc, out, err = run_prog([
        "ekle",
        "Ali", "Yilmaz", "01.01.1990", "Erkek", "50000",
        "bul",
        "C00001",
        "kapat"
    ])
    assert rc == 0, f"rc={rc}\nstderr:\n{err}"
    # Beklenen parçalar (tam satırı değil, alan bazlı kontrol)
    assert "C00001" in out                      # ID (6 sağ)
    assert "Ali                 " in out         # Ad (20 sol)
    assert "Yilmaz         " in out              # Soyad (15 sol)
    assert "01.01.1990" in out                   # DT (10)
    assert "Erkek" in out                        # Cinsiyet (5 sağ)
    assert "50.000,00TL" in out                  # Maaş (TR format)


# TODO[4]: guncelle
def test_todo4_guncelle_updates_salary_and_prints_guncellendi():
    rc, out, err = run_prog([
        "ekle",
        "Ali", "Yilmaz", "01.01.1990", "Erkek", "10000",
        "guncelle",
        "C00001",
        "12000",
        "bul",
        "C00001",
        "kapat"
    ])
    assert rc == 0, f"rc={rc}\nstderr:\n{err}"
    assert "Eklendi" in out
    assert "Güncellendi" in out
    assert "12.000,00TL" in out
    assert "Program kapatıldı." in out

def test_todo4_guncelle_non_existing_prints_bulunamadi():
    rc, out, err = run_prog([
        "guncelle",
        "C00077",
        "99999",
        "kapat"
    ])
    assert rc == 0, f"rc={rc}\nstderr:\n{err}"
    assert "Bulunamadi" in out
    assert "Program kapatıldı." in out


# TODO[5]: liste
def test_todo5_liste_empty_prints_veri_tabani_bos():
    rc, out, err = run_prog([
        "liste",
        "kapat"
    ])
    assert rc == 0, f"rc={rc}\nstderr:\n{err}"
    assert "Veri Tabanı Boş" in out
    assert "Program kapatıldı." in out

def test_todo5_liste_with_two_records_prints_ascii_table_sorted_by_id():
    rc, out, err = run_prog([
        "ekle",
        "Ali", "Yilmaz", "01.01.1990", "Erkek", "50000",
        "ekle",
        "Ayse", "Kara", "02.02.1992", "Kadın", "75000",
        "liste",
        "kapat"
    ])
    assert rc == 0, f"rc={rc}\nstderr:\n{err}"
    # Üst/alt çizgi sabit; başlığı boşluklardan bağımsız doğrula
    assert "+------+--------------------+---------------+----------+-----+---------------+" in out

    header_pattern = re.compile(
        r"\| *ID *\| *Ad *\| *Soyad *\| *DogumTarihi *\| *Cinsiyet *\| *Maas *\|"
    )
    assert header_pattern.search(out), f"Başlık satırı beklenen sütunları içermiyor:\n{out}"
    # Sıralama ve içerik
    assert "C00001" in out and "C00002" in out
    assert "Ali" in out and "Ayse" in out
    assert "50.000,00TL" in out and "75.000,00TL" in out
    assert "Program kapatıldı." in out
