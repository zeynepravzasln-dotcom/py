[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/-7Qu-JCy)
[![Open in Codespaces](https://classroom.github.com/assets/launch-codespace-2972f46106e565e64193e422d61a12cf1da4916b45550586e14ef0a7c637dd04.svg)](https://classroom.github.com/open-in-codespaces?assignment_repo_id=21796067)
# P1-Ödev2 — Personel Takibi

Bu ödev, **input()**, **while**, **if–elif–else**, **sözlük (dict)** ve **metin biçimlendirme** pratiklerini pekiştirmek içindir.  
Kayıt alanları: **ID (otomatik), Ad, Soyad, DogumTarihi, Cinsiyet, Maaş**

📌 **Teslim tarihi:** 23 Kasım 2025 **Pazar 23:59 (Europe/Istanbul)**  
📌 **Puan:** 5 puan (dönem toplamına %5 etkili)

---

## 1) Depo Yapısı

```
README.md                ← Talimatlar (DEĞİŞTİRMEYİN)
src/main.py              ← KODUNUZU YAZACAĞINIZ DOSYA (TODO'ları doldurun)
tests/test_main.py       ← Otomatik testler (DEĞİŞTİRMEYİN)
requirements.txt         ← Gerekli Python paketleri (pytest) (DEĞİŞTİRMEYİN)
.gitignore               ← Gereksiz dosyaları dışarıda tutar (örn. __pycache__) (DEĞİŞTİRMEYİN)
.github/workflows/...    ← Otomatik test ayarı (DEĞİŞTİRMEYİN)
```

✅ **Sadece `src/main.py` dosyasını düzenleyin.**  
❌ Diğer dosyalara dokunmayın (tests/, .github/, .gitignore, requirements.txt).

---

## 2) Görevler (TODO → Çalışır Hâle Getirin)

`src/main.py` içinde **5 adet TODO** vardır. While döngüsü hazırdır; siz **sadece komut akışlarını** tamamlayacaksınız.

### TODO[1] — `ekle`
- Sırayla **Ad**, **Soyad**, **DogumTarihi (GG.AA.YYYY)**, **Cinsiyet**, **Maaş** girişlerini alın.  
- **Otomatik ID** üretin: `C` + **sıfır dolgulu 5 hane**  
  - Örnekler: `next_id=1 → C00001`, `next_id=35 → C00035`  
- Kaydı şu şekilde ekleyin:  
  `db[current_id] = {"ad": ..., "soyad": ..., "dt": ..., "cins": ..., "maas": ...}`  
- `next_id`’yi 1 artırın.  
- **Çıktı:** `Eklendi`

### TODO[2] — `sil`
- **ID** alın.  
- **Varsa** silin → `Silindi`  
- **Yoksa** → `Bulunamadi`

### TODO[3] — `bul`
- **ID** alın.  
- **Yoksa** → `YOK`  
- **Varsa** **tek satır** şu biçimde yazdırın:  
  ```
  ID|Ad|Soyad|DogumTarihi|Cinsiyet|Maaş
  ```
- **Alan hizaları (sabit genişlik):**
  - ID **6 sağ**, Ad **20 sol**, Soyad **15 sol**
  - **DogumTarihi**: `GG.AA.YYYY` (10 karakter) **orta hizalı**
  - **Cinsiyet**: `Erkek`/`Kadın` **5 sağ**
  - **Maaş**: ör. `50.000,00TL`, **15 sağ**

### TODO[4] — `guncelle` (Maaş)
- Sırayla **ID**, **YeniMaaş** alın.  
- **Varsa** `maas` alanını güncelleyin → `Güncellendi`  
- **Yoksa** → `Bulunamadi`

### TODO[5] — `liste` (ASCII tablo)
- **Veri tabanı boşsa** → `Veri Tabanı Boş`  
- **Değilse** ID artan sırada ASCII tablo üretin:

```
+------+--------------------+---------------+----------+-----+---------------+
|  ID  |         Ad        |     Soyad     |DogumTarihi|Cinsiyet|      Maas    |
+------+--------------------+---------------+----------+-----+---------------+
| .... | .................. | ............. |..........|..... |...............|
+------+--------------------+---------------+----------+-----+---------------+
```

- **Sütun genişlikleri / hizalar:**
  - ID (**6 sağ**) – `C00001, C00002, ...`  
  - Ad (**20 sol**), Soyad (**15 sol**)  
  - **DogumTarihi** (**10 orta**, `GG.AA.YYYY`)  
  - Cinsiyet (**5 sağ**)  
  - Maaş (**15 sağ**, ör. `50.000,00TL`)

> **Önemli:** Testler **yalnızca belirtilen çıktı satırlarını** arar. Ekstra açıklama yazdırmayın.

---

## 3) Çalışma Ortamı

### A) GitHub Codespaces
1. Repo sayfasında **Code ▸ Codespaces ▸ Create codespace on main**.  
2. Terminal:
   ```bash
   pytest -q
   ```
3. Kodunuzu `src/main.py` içinde yazın.

### B) Lokal (Miniconda + VSCode)
1. Klonlayın:
   ```bash
   git clone <REPO-URL>
   cd <repo-adi>
   ```
2. Ortam:
   ```bash
   conda create -n p1-odev2 python=3.11 -y
   conda activate p1-odev2
   ```
3. Paketler:
   ```bash
   python -m pip install -U pip
   pip install -r requirements.txt
   ```
4. Test:
   ```bash
   pytest -q
   ```

---

## 4) Programı Çalıştırma

```bash
python src/main.py
```

**Örnek oturum (kısaltılmış):**
```
ekle
Ali
Yilmaz
01.05.2001
Erkek
50000
liste
bul
C00001
kapat
```

---

## 5) Testleri Çalıştırma

Tüm testler:
```bash
pytest -q
```

---

## 6) Teslim

- Son **push**: 23 Kasım 2025 Pazar 23:59 (Europe/Istanbul) öncesi.  
- **EDERS** yükleme:
  - GitHub’dan **Download ZIP**.
  - Zip’te şu dosyalar olmalı: `src/main.py`, `tests/`, `requirements.txt`, `README.md`, `.gitignore`.
  - Bu zip’i **EDERS**’e yükleyin.

📌 **İki teslim zorunludur (GitHub Classroom + EDERS).**

---

## 7) Değerlendirme (5 puan)

- **TODO[1]** `ekle` (otomatik ID + kayıt) → 1.0p  
- **TODO[2]** `sil` → 1.0p  
- **TODO[3]** `bul` (biçim) → 1.0p  
- **TODO[4]** `guncelle` (maaş) → 1.0p  
- **TODO[5]** `liste` (ASCII tablo) → 1.0p
