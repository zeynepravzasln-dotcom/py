"""
Ödev 2: Personel Takibi, Komutları input() ile alın; while içinde if-elif-else ile işleyin.
Not: Testler sadece belirtilen çıktı satırlarını bekler. Ekstra açıklama yazdırmayın.
"""

if __name__ == "__main__":
    # Ana veri yapısı ve ID sayacı (öğrenci buraya DOKUNMAZ)
    db = {}          # db[ID] = {"ad": str, "soyad": str, "dt": str, "cins": str, "maas": str}
    next_id = 1      # ID formatı --> C0001, C0002, ...

    # bu kodlara dokunmayınız
    while True:
        try:
            print('''
                Personel Takip Sistemi v1.0
                ---------------------------------------
                Komut Listesi:
                ---------------------------------------
                |kapat    | uygulamayı sonlandır      |
                |ekle     | personel ekle             |
                |sil      | personel sil              |
                |bul      | personel bul              |
                |guncelle | personel maas guncelle    |
                |liste    | personel listele          |
                ---------------------------------------
                ''')
            cmd = input('Komutu giriniz:').strip().lower()
        except EOFError:
            break
        if not cmd:
            continue

        if cmd == "kapat":
            print("Program kapatıldı.")
            break

        elif cmd == "ekle":
            # DONE[1]: 5 satır oku: ad, soyad, dt (DD.MM.YYYY), cins, maas
            # - current_id = ?  ---> ornegın next_id=35 icin C00035 formatında olmalı!
            # - db[current_id] = {...} seklinde ekle 
            # - next_id += 1
            # - "Eklendi" yazdır
            ad = input("")
            soyad = input("")
            dt = input("")
            cins = input("")
            maas = input("")

            current_id = f"C{next_id:05d}"
            db[current_id] = {
                "ad": ad,
                "soyad": soyad,
                "dt": dt,
                "cins": cins,
                "maas": maas
            }

            next_id += 1
            print("Eklendi")


            

        elif cmd == "sil":
            # DONE[2]: 1 satır ID al
            # - ID varsa sil → "Silindi" yazdır
            # - yoksa → "Bulunamadi" yazdır
            ID = input()
            if ID in db:
                del db[ID]
                print("Silindi")
            else:
                print("Bulunamadi")
            
        

        elif cmd == "bul":
            # DONE[3]: 1 satır ID al
            # - yoksa "YOK"
            # - varsa "ID|Ad|Soyad|DoğumTarihi|Cinsiyet|Maaş" yazdır
            # - ID (6 Karakter Saga Yaslı)
            # - Ad (20 Karakter Sola Yaslı)
            # - Soyad (15 Karakter Sola Yaslı)
            # - DoğumTarihi ( GG.AA.YYYY formatında 10 karakter Ortaya Hizalı)
            # - Cinsiyet (Erkek yada Kadın 5 karakter sağa yaslı)
            # - Maaş (örneğin 50.000,00TL formatında 15 karakter sağa yaslı)
            ID = input().strip()
            if ID not in db:
                print("YOK")
            else:
                p = db[ID]
                maas = "{:,.2f}".format(float(p["maas"])).replace(",", "X").replace(".", ",").replace("X", ".") + "TL"
                print(f"{ID:>6}|{p['ad']:<20}|{p['soyad']:<15}|{p['dt']:^10}|{p['cins']:>6}|{maas:>15}")

            pass

        elif cmd == "guncelle":
            # DONE[4]: 2 satır al: ID, YeniMaaş sadece maasi guncellemeniz yeterli
            # - varsa db[ID]["maas"] = YeniMaaş ve "Güncellendi" yazdır
            # - yoksa → "Bulunamadi" yazdır
            ID = input().strip()
            if ID in db:
                YeniMaas = input()
                db[ID]["maas"] = YeniMaas
                print("Güncellendi")
            else:
                print("Bulunamadi")



        elif cmd == "liste":
            # DONE[5]: db boşsa "Veri Tabanı Boş"
            # değilse ASCII tablo yazdır:
            #   +----+----+-------+-------------+----------+------+
            #   | ID | Ad | Soyad | DoğumTarihi | Cinsiyet | Maaş |
            #   +----+----+-------+-------------+----------+------+
            #   | .. | .. |  ...  |    ....     |   ...    | ...  |
            #   +----+----+-------+-------------+----------+------+
            # Kurallar:
            # - ID (6 Karakter Saga Yaslı) C0001, C0002, ... formatında
            # - Ad (20 Karakter Sola Yaslı)
            # - Soyad (15 Karakter Sola Yaslı)
            # - DoğumTarihi ( GG.AA.YYYY formatında 10 karakter Ortaya Hizalı)
            # - Cinsiyet (Erkek yada Kadın 5 karakter sağa yaslı)
            # - Maaş (örneğin 50.000,00TL formatında 15 karakter sağa yaslı) 
            if not db:
                print("Veri Tabanı Boş")
            else:      
                print("+------+--------------------+---------------+----------+-----+---------------+")
                print("| ID   | Ad                 | Soyad         |DogumTarihi |Cinsiyet|      Maas       |")
                print("+------+--------------------+---------------+----------+-----+---------------+")

                for ID in sorted(db.keys()):
                    p = db[ID]
                    maas_tr = "{:,.2f}TL".format(float(p["maas"])).replace(",", "X").replace(".", ",").replace("X", ".")
                    print(f"|{ID:^6}|{p['ad']:<20}|{p['soyad']:<15}|{p['dt']:^10}|{p['cins']:>6}|{maas_tr:>15}|")
                print("+------+--------------------+---------------+------------+--------+---------------+")
          

        else:
            print(f"'{cmd}' Komutu Tanımlı Değil!")
             
