if __name__ == "__main__":
    # Ödev 1: Koşullu Yapılar (print, input, if-elif-else)  
    # Kurallar:
    # - Her aşamayı tamamladığınızda satır başındaki 'TODO[n]' ifadesini 'DONE[n]' ile değiştirin.
    # - Kodunuzu ilgili yorumun ALTINA yazın. Yorumları silmeyin.

    # Aşamalar:
    # DONE[1]: input() ile kullanıcıdan notu al
    spuan = input('Aldığınız notu giriniz:')

    # DONE[2]: rakam olmayan değerler için hata/uyarı verin
    try:
        spuan = int(spuan)
    except:
        print("Hatalı Değer Girdiniz!!!")
        spuan = None

    # DONE[3]: 0-100 aralığı dışında değerler için hata/uyarı verin
    if spuan is not None :
        if 0<= spuan <=100:
            print("notunuz : {spuan}")
        else:
            print("Hata, geçerli not giriniz!!!")
            spuan = None
    
    # DONE[4]: 0-100 aralığındaki notu sınıflandırın (AA, BA, BB, CB, CC, DC, DD, FD, FF)
    if spuan is not None :
        if spuan>=90 and spuan<=100 :
            grade="AA"
        elif spuan>=80 and spuan<90 :
            grade="BA"
        elif spuan>=75 and spuan<80 :
            grade="BB"
        elif spuan>=70 and spuan<75 :
            grade="CB"
        elif spuan>=60 and spuan<70 :
            grade="CC"
        elif spuan>=50 and spuan<60 :
            grade="DC"
        elif spuan>=40 and spuan<50 :
            grade="DD"
        elif spuan>=30 and spuan<40 :
            grade="FD"
        else :
            grade="FF"
        

    # DONE[5]: Sonucu ekrana yazdırın (sadece harf notunu yazdırmanız yeterli)
    print(grade)

