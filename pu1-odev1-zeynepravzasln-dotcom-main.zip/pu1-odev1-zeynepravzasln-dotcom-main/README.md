[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/y453zJWr)
[![Open in Codespaces](https://classroom.github.com/assets/launch-codespace-2972f46106e565e64193e422d61a12cf1da4916b45550586e14ef0a7c637dd04.svg)](https://classroom.github.com/open-in-codespaces?assignment_repo_id=21093114)
# P1-Ödev1-Koşullu

Bu ödev, **print**, **input**, **if–elif–else** ve **mantıksal kontrolleri** pekiştirici ödevdir.

📌 **Teslim tarihi:** 21 Ekim 2025 **Salı 23:59 (Europe/Istanbul)**  
📌 **Puan:** 5 puan (dönem toplamına %5 etkili)

---

## 1) Bu Depoda Neler Var?

```
README.md                ← Talimatlar (DEĞİŞTİRMEYİN)
src/main.py              ← KODUNUZU YAZACAĞINIZ DOSYA (TODO'ları doldurun)
tests/test_main.py       ← Otomatik testler (DEĞİŞTİRMEYİN)
requirements.txt         ← Gerekli Python paketleri (pytest) (DEĞİŞTİRMEYİN)
.gitignore               ← Gereksiz dosyaları dışarıda tutar (örn. __pycache__) (DEĞİŞTİRMEYİN)
.github/workflows/...    ← Otomatik test ayarı (DEĞİŞTİRMEYİN)
```

✅ **Sadece `src/main.py` dosyasını düzenleyin.**  
❌ Diğer dosyalara dokunmayın (tests/, .github/, .gitignore, requirements.txt).

---

## 2) Görevler (TODO → DONE)

`src/main.py` dosyasında **5 adet TODO** vardır:

1. **TODO[1]:** Kullanıcıdan notu al  
2. **TODO[2]:** Sayı olmayan girişlerde hata/uyarı ver  
3. **TODO[3]:** 0–100 dışı girişlerde hata/uyarı ver  
4. **TODO[4]:** 0–100 içindeki notu harf notuna çevir:  
   - 90–100 → **AA**  
   - 80–89  → **BA**  
   - 75–79  → **BB**  
   - 70–74  → **CB**  
   - 60–69  → **CC**  
   - 50–59  → **DC**  
   - 40–49  → **DD**  
   - 30–39  → **FD**  
   - 0–29   → **FF**  
5. **TODO[5]:** Sonucu ekrana yazdır (çıktı boş kalmasın)

📝 **Kural:**  
- Her aşamayı tamamladığınızda `TODO[n]` ifadesini `DONE[n]` ile değiştirin.  
- Kodunuzu ilgili yorumun ALTINA yazın.  
- Yorumları silmeyin.  

Testler hem kodunuzu hem de `DONE` etiketlerini kontrol eder.

---

## 3) Çalışma Ortamı Seçenekleri

### 🔹 A) GitHub Codespaces (Tarayıcı Üzerinde)

1. GitHub repo sayfasına gidin.  
2. **Code ▸ Codespaces ▸ Create codespace on main** seçeneğini tıklayın.  
3. Tarayıcıda otomatik olarak VSCode benzeri bir ortam açılacaktır.  
   - Python ve pytest hazır gelecektir.  
4. Terminalden testleri çalıştırın:  
   ```bash
   pytest -q
   ```
5. Kodunuzu `src/main.py` içine yazın.  

> **Avantaj:** Bilgisayara kurulum gerekmez.  
> **Not:** İnternet bağlantısı gereklidir.

---

### 🔹 B) Lokal Kurulum (Miniconda + VSCode)

1. **Depoyu Klonlayın**
   ```bash
   git clone <KOPYALADIĞINIZ-URL>
   cd <repo-adi>
   ```

2. **Conda Ortamı Oluşturun**
   ```bash
   conda create -n p1-odev1 python=3.11 -y
   conda activate p1-odev1
   ```

3. **Gerekli Paketleri Kurun**
   ```bash
   python -m pip install -U pip
   pip install -r requirements.txt
   ```

4. **VSCode ile Açın**
   - VSCode’da repo klasörünü açın.  
   - Sol alt köşeden Python interpreter seçin → `p1-odev1`.  
   - Terminali açarak testleri çalıştırın:  
     ```bash
     pytest -q
     ```

---

## 4) Programı Çalıştırma

Terminalde:
```bash
python -m src.main
```

Örnek girişler:  
- `95` → AA  
- `85` → BA  
- `20` → FF  
- `120` → hata/uyarı  
- `abc` → hata/uyarı  

---

## 5) Testleri Çalıştırma

Tüm testler:
```bash
pytest -q
```

Belirli test:
```bash
pytest tests/test_main.py::test_todo4_siniflandirma -q
```

---

## 6) Git ile Kaydetme ve Gönderme

```bash
git add .
git commit -m "TODO[1-5] tamamlandı"
git push
```

Push’tan sonra GitHub’daki **Actions** sekmesinden testlerin geçtiğini kontrol edin.

---

## 7) Teslim

- Son `push` **21 Ekim 2025 Salı 23:59 (Europe/Istanbul)** öncesinde yapılmalıdır.  
- UBYS’ye yüklemek için:  
  - GitHub’dan son halini **Download ZIP** yapın.  
  - İçinde `src/main.py`, `tests/`, `requirements.txt`, `README.md`, `.gitignore` olmalıdır.  
  - Bu zip’i UBYS’ye yükleyin.  

📌 **İki teslim zorunludur (GitHub Classroom + UBYS).**

---

## 8) Değerlendirme (5 puan)

- **TODO[1]** Kullanıcıdan not alma → 1.0p  
- **TODO[2]** Sayı olmayan girişlerde hata/uyarı → 1.0p  
- **TODO[3]** 0–100 dışı girişlerde hata/uyarı → 1.0p  
- **TODO[4]** Harf notuna çevirme (AA–FF) → 1.0p  
- **TODO[5]** Sonucu ekrana yazdırma → 1.0p  

---

👉 Artık öğrenciler ister **GitHub Codespaces** üzerinden, ister **local Miniconda + VSCode** kurulumuyla rahatça çalışabilir.  
