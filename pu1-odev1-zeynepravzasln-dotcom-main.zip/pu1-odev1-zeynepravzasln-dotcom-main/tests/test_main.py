import subprocess
import sys
from pathlib import Path
import re

PYTHON = sys.executable
ROOT = Path(__file__).resolve().parents[1]
MAIN_PATH = ROOT / "src" / "main.py"
MAIN = str(MAIN_PATH)

def run_prog(inp: str):
    proc = subprocess.run(
        [PYTHON, MAIN],
        input=inp.encode(),
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        check=False,
    )
    try:
        out = proc.stdout.decode("utf-8")
    except UnicodeDecodeError:
        out = proc.stdout.decode("latin-1", errors="ignore")  # fallback
    return out.strip(), proc.returncode

SRC = MAIN_PATH.read_text(encoding="utf-8")

def _has_done(n: int) -> bool:
    return f"DONE[{n}]" in SRC

def _assert_step_done(n: int):
    assert _has_done(n), f"TODO[{n}] → DONE[{n}] yapılmamış."

def _has_error(s: str) -> bool:
    s = s.lower()
    return ("hata" in s) or ("uyarı" in s) or ("geçersiz" in s)

# -------------------- 4 TEST --------------------

def test_todo1_input_alma():
    """TODO[1]: input ile değeri alma (ve program çökmemeli)."""
    out, code = run_prog("42\n")
    assert code == 0                 # program çalışmalı
    _assert_step_done(1)             # DONE[1] işaretlenmiş ve altında kod var

def test_todo2_sayi_olmayan_kontrolu():
    """TODO[2]: sayı olmayan girişlerde uyarı/hata vermeli."""
    out_str, _  = run_prog("abc\n")
    assert _has_error(out_str)
    _assert_step_done(2)

def test_todo3_gecersiz_kontrolu():
    """TODO[3]: 0-100 dışı girişlerde uyarı/hata vermeli."""
    out_high, _ = run_prog("120\n")
    out_neg, _  = run_prog("-5\n")
    assert _has_error(out_high)
    assert _has_error(out_neg)
    _assert_step_done(3)

def test_todo4_siniflandirma():
    """TODO[4]: geçerli aralıklar için tüm harf notlarını kontrol et."""
    # Beklenen: 95 → AA
    out, _ = run_prog("95\n")
    assert "AA" in out
    # Beklenen: 85 → BA
    out, _ = run_prog("85\n")
    assert "BA" in out
    # Beklenen: 77 → BB
    out, _ = run_prog("77\n")
    assert "BB" in out
    # Beklenen: 72 → CB
    out, _ = run_prog("72\n")
    assert "CB" in out
    # Beklenen: 65 → CC
    out, _ = run_prog("65\n")
    assert "CC" in out
    # Beklenen: 55 → DC
    out, _ = run_prog("55\n")
    assert "DC" in out
    # Beklenen: 45 → DD
    out, _ = run_prog("45\n")
    assert "DD" in out
    # Beklenen: 35 → FD
    out, _ = run_prog("35\n")
    assert "FD" in out
    # Beklenen: 20 → FF
    out, _ = run_prog("20\n")
    assert "FF" in out
    _assert_step_done(4)

def test_todo5_cikti_uretim():
    """TODO[5]: sonucu ekrana yazdırma (herhangi bir geçerli girdiyle)."""
    out, _ = run_prog("60\n")
    assert out.strip() != ""        # boş çıktı olmamalı
    _assert_step_done(5)
